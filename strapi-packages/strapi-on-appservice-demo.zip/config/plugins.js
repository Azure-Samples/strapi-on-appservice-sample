export default ({ env }) => ({
  email: {
    config: {
      provider: 'strapi-provider-email-azure',
      providerOptions: {
        useManagedIdentity: env.bool('EMAIL_MANAGED_IDENTITY_ENABLED', true),
        endpoint: env('AZURE_EMAIL_SERVICE_ENDPOINT'),
        identityClientId: env('ENTRA_CLIENT_ID')
      },
      settings: {
        defaultFrom: env('FROM_EMAIL')
      }
    }
  },
  upload: {
    config: {
      provider: 'strapi-provider-upload-azure-storage',
      providerOptions: {
        authType: env("STORAGE_AUTH_TYPE", "msi"),
        account: env("STORAGE_ACCOUNT_NAME"),
        clientId: env("ENTRA_CLIENT_ID"),
        accountKey: env("STORAGE_ACCOUNT_KEY"),
        serviceBaseURL: env("BLOB_STORAGE_URL"),
        containerName: env("BLOB_CONTAINER_NAME"),
        defaultPath: "uploads"
      }
    }
  }
});