/**
 * lead-form-submission service.
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::lead-form-submission.lead-form-submission');
