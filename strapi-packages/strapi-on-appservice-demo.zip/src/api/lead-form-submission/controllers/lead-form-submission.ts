/**
 *  lead-form-submission controller
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::lead-form-submission.lead-form-submission');
