/**
 * lead-form-submission router.
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::lead-form-submission.lead-form-submission');
